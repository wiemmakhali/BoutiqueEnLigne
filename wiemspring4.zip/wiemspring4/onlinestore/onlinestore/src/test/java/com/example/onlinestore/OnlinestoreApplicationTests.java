package com.example.onlinestore;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnlinestoreApplicationTests {

	@Test
	void contextLoads() {
	}

}
