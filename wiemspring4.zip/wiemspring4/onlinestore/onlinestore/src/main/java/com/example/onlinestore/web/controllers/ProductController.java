package com.example.onlinestore.web.controllers;

import com.example.onlinestore.web.models.Product;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.ArrayList;
import java.util.List;

@Controller
public class ProductController {

    private static List<Product> products = new ArrayList<Product>();
    private static Long idCount = 100L;

    static {
        products.add(new Product(++idCount, "SS-S9", "Samsung Galaxy S9", 556.0, 5, "samsung-s9.png"));
        products.add(new Product(++idCount, "NK-51", "Nokia 5.1 Plus", 640.0, 6, null));
        products.add(new Product(++idCount, "IP-7", "iPhone 7", 600.0, 38, "iphone-7.png"));
    }

    @GetMapping({"/", "/products"})
    public String listProducts(Model model) {
        model.addAttribute("products", products);
        return "list";
    }
}
